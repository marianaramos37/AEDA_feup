var searchData=
[
  ['data_142',['Data',['../class_data.html#af11f741cb7f587e2e495452a8905a22a',1,'Data::Data()'],['../class_data.html#aebec784a98dfb305e38edb04d7dfc61c',1,'Data::Data(string d)']]]
];
