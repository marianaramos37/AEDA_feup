var searchData=
[
  ['cliente_115',['Cliente',['../class_cliente.html',1,'']]],
  ['clientenalistanegra_116',['ClienteNaListaNegra',['../class_cliente_na_lista_negra.html',1,'']]]
];
