var searchData=
[
  ['addadmin_0',['addAdmin',['../class_base.html#adaed88857f9eebdc428546799d4763c9',1,'Base']]],
  ['addcliente_1',['addCliente',['../class_base.html#a28850bfd675544d375db86c56c0195f1',1,'Base']]],
  ['addentreg_2',['addEntreg',['../class_base.html#a2c299968679e35c06344ff1da05472cb',1,'Base']]],
  ['addrestaurante_3',['addRestaurante',['../class_base.html#a592b29d7d5e6ff3ecd7a16d9f61abc99',1,'Base']]],
  ['addtecnico_4',['addTecnico',['../class_base.html#a69805cd2889fa42feb5f576588af0566',1,'Base']]],
  ['addtecnicotofila_5',['addTecnicoToFila',['../class_base.html#aad6cb727834a8105f8e8288646d28e40',1,'Base']]],
  ['administrador_6',['Administrador',['../class_administrador.html',1,'Administrador'],['../class_administrador.html#a6bb8fdf1b52a22a150d9fdea9d1e52db',1,'Administrador::Administrador()']]],
  ['ano_7',['ano',['../class_data.html#a80d76fe2225d187fe8a20414478a2cb5',1,'Data']]]
];
