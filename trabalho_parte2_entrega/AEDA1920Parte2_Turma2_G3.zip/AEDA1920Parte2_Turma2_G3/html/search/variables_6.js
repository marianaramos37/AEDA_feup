var searchData=
[
  ['gerente_204',['gerente',['../class_base.html#a05eccb6433822707e846a7ff70e1a946',1,'Base']]]
];
