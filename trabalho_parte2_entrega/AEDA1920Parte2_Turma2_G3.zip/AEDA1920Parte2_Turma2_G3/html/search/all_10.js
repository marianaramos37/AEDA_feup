var searchData=
[
  ['veiculo_91',['Veiculo',['../class_veiculo.html',1,'']]],
  ['veiculo_5falocado_92',['veiculo_alocado',['../class_entregador.html#a008a76e789c498c23e3ca1cdf3720e5d',1,'Entregador']]]
];
