var searchData=
[
  ['tecnico_129',['Tecnico',['../class_tecnico.html',1,'']]]
];
