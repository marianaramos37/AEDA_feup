var searchData=
[
  ['listanegra_5freadfile_151',['listaNegra_readfile',['../class_base.html#a714900778cfda0a00088fd36f541d99d',1,'Base']]]
];
