var searchData=
[
  ['tecnico_169',['Tecnico',['../class_tecnico.html#a55698f063f7f301fd7a7d05f23787ad2',1,'Tecnico']]]
];
