var searchData=
[
  ['_7eadministrador_170',['~Administrador',['../class_administrador.html#a0e044ad3a41da3a0ff2c1ec7ef8fa800',1,'Administrador']]],
  ['_7ebase_171',['~Base',['../class_base.html#a722da881b6c70cfcbde9243abcfbf334',1,'Base']]],
  ['_7ecliente_172',['~Cliente',['../class_cliente.html#a29d1d53394350c66363109e33c990b58',1,'Cliente']]],
  ['_7edata_173',['~Data',['../class_data.html#aab31956423290f0d62dcca47ab4d16dd',1,'Data']]],
  ['_7eempresa_174',['~Empresa',['../class_empresa.html#a3c03ed7fbfdaa5c8db9b8587451f1326',1,'Empresa']]],
  ['_7eencomenda_175',['~Encomenda',['../class_encomenda.html#a2139d9174c2888a59f871e63266398f1',1,'Encomenda']]],
  ['_7eentregador_176',['~Entregador',['../class_entregador.html#afab1f1ed9d1d4b2adf1afdb0562cb877',1,'Entregador']]],
  ['_7efuncionario_177',['~Funcionario',['../class_funcionario.html#a800273bd909dc88f821a414abebc442c',1,'Funcionario']]],
  ['_7emorada_178',['~Morada',['../class_morada.html#a4502523e15ce7da129d8bdf4b32359db',1,'Morada']]],
  ['_7eprato_179',['~Prato',['../class_prato.html#a3c17941e0d768523c109a2d01406aece',1,'Prato']]],
  ['_7erestaurante_180',['~Restaurante',['../class_restaurante.html#af115daf26147e0aeda0f1c10bc414c6e',1,'Restaurante']]],
  ['_7etecnico_181',['~Tecnico',['../class_tecnico.html#a8a502d3419ab38fa212da093f7c98528',1,'Tecnico']]]
];
