var searchData=
[
  ['listanegra_206',['listaNegra',['../class_base.html#a7a00416ba7dbb5b9768a2176a0fdb0ab',1,'Base']]],
  ['localidade_207',['localidade',['../class_morada.html#a905952ce6f49c5fb9cc397b07bd1aef0',1,'Morada']]]
];
