var searchData=
[
  ['listanegra_50',['listaNegra',['../class_base.html#a7a00416ba7dbb5b9768a2176a0fdb0ab',1,'Base']]],
  ['listanegra_5freadfile_51',['listaNegra_readfile',['../class_base.html#a714900778cfda0a00088fd36f541d99d',1,'Base']]],
  ['localidade_52',['localidade',['../class_morada.html#a905952ce6f49c5fb9cc397b07bd1aef0',1,'Morada']]]
];
