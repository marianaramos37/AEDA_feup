var searchData=
[
  ['base_183',['base',['../class_cliente.html#a69bfcaa06e14aa860b8f43d736351a59',1,'Cliente']]],
  ['bases_184',['bases',['../class_empresa.html#a55bc9f3802b54e1995c37fefa10b1c9f',1,'Empresa']]]
];
