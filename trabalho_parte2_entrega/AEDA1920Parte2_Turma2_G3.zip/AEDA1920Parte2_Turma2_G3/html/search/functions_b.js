var searchData=
[
  ['sortrestaurantesporcomida_167',['sortRestaurantesPorComida',['../class_restaurante.html#acac4ef46a30a661170433e63b22da982',1,'Restaurante']]],
  ['sortrestaurantesporzona_168',['sortRestaurantesPorZona',['../class_restaurante.html#aa2f39ff3240bfd6a68be7b4429b86f5b',1,'Restaurante']]]
];
