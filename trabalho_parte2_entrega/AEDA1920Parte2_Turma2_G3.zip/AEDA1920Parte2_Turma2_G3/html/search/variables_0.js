var searchData=
[
  ['ano_182',['ano',['../class_data.html#a80d76fe2225d187fe8a20414478a2cb5',1,'Data']]]
];
