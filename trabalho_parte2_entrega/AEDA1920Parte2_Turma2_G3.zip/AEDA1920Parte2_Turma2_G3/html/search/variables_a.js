var searchData=
[
  ['name_211',['name',['../class_cliente.html#a5ad7b891ad6197af78220aa7eec6cc85',1,'Cliente']]],
  ['nif_212',['nif',['../class_cliente.html#aaa10bfea598747e19f6587604ec87105',1,'Cliente::nif()'],['../class_funcionario.html#a9bdd9ddf9a0e407871d9ba6b535ef02e',1,'Funcionario::nif()']]],
  ['nome_213',['nome',['../class_prato.html#a044bfe52b405e42cb5730924211b5520',1,'Prato::nome()'],['../class_funcionario.html#a9415993338314799ac6ec08f4441578e',1,'Funcionario::nome()'],['../class_restaurante.html#afea10d1a11d07a5f8a08a2f11b4d26e9',1,'Restaurante::nome()']]],
  ['numero_214',['numero',['../class_morada.html#a40bab883273b83933ab1963b9014b33b',1,'Morada']]]
];
