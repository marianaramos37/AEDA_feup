var searchData=
[
  ['removeadmin_68',['removeAdmin',['../class_base.html#a146228c71d8ed3b8916baa86cbfa5116',1,'Base']]],
  ['removecliente_69',['removeCliente',['../class_base.html#acc6172594c9dff6b4beba3ef26ac4ae4',1,'Base']]],
  ['removeentreg_70',['removeEntreg',['../class_base.html#a1bc6fb7a86da708a8d21e11bf24a4ba0',1,'Base']]],
  ['removefuncionario_71',['removeFuncionario',['../class_base.html#af26bcd33867ddb80452f3aaeac7b1040',1,'Base']]],
  ['removerestaurante_72',['removeRestaurante',['../class_base.html#a4ae2252cefffd65f429b9243b58731b3',1,'Base']]],
  ['removetecnico_73',['removeTecnico',['../class_base.html#ac452de7cad0150fca1ca3cf54477420e',1,'Base']]],
  ['removetecnicofromfila_74',['removeTecnicoFromFila',['../class_base.html#adbc2899197a9f0eb2bf789dd4aa60492',1,'Base']]],
  ['restaurante_75',['Restaurante',['../class_restaurante.html',1,'Restaurante'],['../class_restaurante.html#ae96329273fb6568baa886d469a4b82f4',1,'Restaurante::Restaurante()'],['../class_restaurante_inexistente.html#a51727fae69311a9804296521dd7cd457',1,'RestauranteInexistente::restaurante()']]],
  ['restauranteinexistente_76',['RestauranteInexistente',['../class_restaurante_inexistente.html',1,'RestauranteInexistente'],['../class_restaurante_inexistente.html#af2ca79128c23a15ab312c183cec18196',1,'RestauranteInexistente::RestauranteInexistente()']]],
  ['restaurantenome_77',['restauranteNome',['../class_encomenda.html#a70aaccc28ed3e84e19a05e9ac0619da7',1,'Encomenda']]],
  ['restaurantes_78',['restaurantes',['../class_base.html#a1b81f01c593fd5b581991067f6cfc4ea',1,'Base']]],
  ['restaurantes_5ffilename_79',['restaurantes_filename',['../class_base.html#aaf43a3482c9ffbd3a0b60714b94e9478',1,'Base']]],
  ['restaurantes_5freadfile_80',['restaurantes_readfile',['../class_base.html#a4becd0991c08c6c13c6e18fe983e7743',1,'Base']]],
  ['rua_81',['rua',['../class_morada.html#af48005a99f47c7041e4e31fa0a9a7a03',1,'Morada']]]
];
