var searchData=
[
  ['addadmin_131',['addAdmin',['../class_base.html#adaed88857f9eebdc428546799d4763c9',1,'Base']]],
  ['addcliente_132',['addCliente',['../class_base.html#a28850bfd675544d375db86c56c0195f1',1,'Base']]],
  ['addentreg_133',['addEntreg',['../class_base.html#a2c299968679e35c06344ff1da05472cb',1,'Base']]],
  ['addrestaurante_134',['addRestaurante',['../class_base.html#a592b29d7d5e6ff3ecd7a16d9f61abc99',1,'Base']]],
  ['addtecnico_135',['addTecnico',['../class_base.html#a69805cd2889fa42feb5f576588af0566',1,'Base']]],
  ['addtecnicotofila_136',['addTecnicoToFila',['../class_base.html#aad6cb727834a8105f8e8288646d28e40',1,'Base']]],
  ['administrador_137',['Administrador',['../class_administrador.html#a6bb8fdf1b52a22a150d9fdea9d1e52db',1,'Administrador']]]
];
