var searchData=
[
  ['restaurante_127',['Restaurante',['../class_restaurante.html',1,'']]],
  ['restauranteinexistente_128',['RestauranteInexistente',['../class_restaurante_inexistente.html',1,'']]]
];
