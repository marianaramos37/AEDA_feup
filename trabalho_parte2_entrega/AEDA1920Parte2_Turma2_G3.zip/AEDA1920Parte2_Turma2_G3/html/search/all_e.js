var searchData=
[
  ['salario_82',['salario',['../class_funcionario.html#ad305ae6211b99d73461cccc647abb62c',1,'Funcionario']]],
  ['sortrestaurantesporcomida_83',['sortRestaurantesPorComida',['../class_restaurante.html#acac4ef46a30a661170433e63b22da982',1,'Restaurante']]],
  ['sortrestaurantesporzona_84',['sortRestaurantesPorZona',['../class_restaurante.html#aa2f39ff3240bfd6a68be7b4429b86f5b',1,'Restaurante']]],
  ['sucesso_85',['sucesso',['../class_encomenda.html#acd6c399ecc73477e73b06737a31e9520',1,'Encomenda']]]
];
