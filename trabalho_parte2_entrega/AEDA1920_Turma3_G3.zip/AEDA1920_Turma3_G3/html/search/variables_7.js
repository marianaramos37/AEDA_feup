var searchData=
[
  ['hora_395',['hora',['../class_encomenda.html#a620b412d34ba74176273677bf9fdd3e3',1,'Encomenda']]]
];
