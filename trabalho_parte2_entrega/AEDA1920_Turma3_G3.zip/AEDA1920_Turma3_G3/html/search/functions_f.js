var searchData=
[
  ['veiculo_356',['Veiculo',['../class_veiculo.html#aafab27708a2639bc83a4c3721e57d196',1,'Veiculo::Veiculo()'],['../class_veiculo.html#a5691b7638f9780fdd17860140329d9a8',1,'Veiculo::Veiculo(string v)']]],
  ['verclientes_357',['verClientes',['../main_8cpp.html#a97a18d82607db44a13cb74ecf3340cdd',1,'main.cpp']]],
  ['verencomendas_358',['verEncomendas',['../main_8cpp.html#a2a22c272d5d0b55c940f0f5fba154ba4',1,'main.cpp']]],
  ['verfunc_359',['verFunc',['../main_8cpp.html#ae20d3bf7529068170e731d9483193ead',1,'main.cpp']]],
  ['verrest_360',['verRest',['../main_8cpp.html#a9fb06d593f7d4de889dca51a2c6d9d75',1,'main.cpp']]]
];
