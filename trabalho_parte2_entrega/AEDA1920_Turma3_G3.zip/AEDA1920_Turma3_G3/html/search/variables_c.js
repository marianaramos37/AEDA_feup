var searchData=
[
  ['restaurante_408',['restaurante',['../class_restaurante_inexistente.html#a51727fae69311a9804296521dd7cd457',1,'RestauranteInexistente']]],
  ['restaurantenome_409',['restauranteNome',['../class_encomenda.html#a70aaccc28ed3e84e19a05e9ac0619da7',1,'Encomenda']]],
  ['restaurantes_410',['restaurantes',['../class_base.html#a1b81f01c593fd5b581991067f6cfc4ea',1,'Base']]],
  ['restaurantes_5ffilename_411',['restaurantes_filename',['../class_base.html#aaf43a3482c9ffbd3a0b60714b94e9478',1,'Base']]],
  ['rua_412',['rua',['../class_morada.html#af48005a99f47c7041e4e31fa0a9a7a03',1,'Morada']]]
];
