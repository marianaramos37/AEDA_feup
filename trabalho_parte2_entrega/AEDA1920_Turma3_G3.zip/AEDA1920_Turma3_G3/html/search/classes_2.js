var searchData=
[
  ['cliente_202',['Cliente',['../class_cliente.html',1,'']]],
  ['clientenalistanegra_203',['ClienteNaListaNegra',['../class_cliente_na_lista_negra.html',1,'']]]
];
