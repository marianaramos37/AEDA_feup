var searchData=
[
  ['salario_413',['salario',['../class_funcionario.html#ad305ae6211b99d73461cccc647abb62c',1,'Funcionario']]],
  ['sucesso_414',['sucesso',['../class_encomenda.html#acd6c399ecc73477e73b06737a31e9520',1,'Encomenda']]]
];
