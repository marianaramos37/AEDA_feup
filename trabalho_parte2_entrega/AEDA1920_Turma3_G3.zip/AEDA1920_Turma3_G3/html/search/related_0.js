var searchData=
[
  ['operator_3c_3c_420',['operator&lt;&lt;',['../class_cliente_na_lista_negra.html#a582d94de423e2ebb4f09d47c2f2c0935',1,'ClienteNaListaNegra::operator&lt;&lt;()'],['../class_funcionario_inexistente.html#afd3e49cf9d44c46e4eb1378237703455',1,'FuncionarioInexistente::operator&lt;&lt;()'],['../class_restaurante_inexistente.html#a5af77834d5cec68f60caf0d1792af4e3',1,'RestauranteInexistente::operator&lt;&lt;()']]]
];
