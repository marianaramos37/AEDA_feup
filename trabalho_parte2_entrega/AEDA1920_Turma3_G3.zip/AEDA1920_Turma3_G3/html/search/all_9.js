var searchData=
[
  ['listaencomendas_92',['listaEncomendas',['../main_8cpp.html#a22c5c0a767c1556d64af27b34cb4cee3',1,'main.cpp']]],
  ['listanegra_93',['listaNegra',['../class_base.html#a7a00416ba7dbb5b9768a2176a0fdb0ab',1,'Base']]],
  ['listanegra_5freadfile_94',['listaNegra_readfile',['../class_base.html#a714900778cfda0a00088fd36f541d99d',1,'Base']]],
  ['localidade_95',['localidade',['../class_morada.html#a905952ce6f49c5fb9cc397b07bd1aef0',1,'Morada']]],
  ['login_96',['login',['../main_8cpp.html#af76b7b46958dabf5e4ee9a492f0ec3fa',1,'main.cpp']]]
];
