var searchData=
[
  ['registo_301',['registo',['../main_8cpp.html#aed9c1384debe4ea72586f808d7e9c12e',1,'main.cpp']]],
  ['removeadmin_302',['removeAdmin',['../class_base.html#a146228c71d8ed3b8916baa86cbfa5116',1,'Base']]],
  ['removecliente_303',['removeCliente',['../class_base.html#acc6172594c9dff6b4beba3ef26ac4ae4',1,'Base']]],
  ['removeentreg_304',['removeEntreg',['../class_base.html#a1bc6fb7a86da708a8d21e11bf24a4ba0',1,'Base']]],
  ['removefunc_305',['removeFunc',['../main_8cpp.html#a58f4970fe4fedc5594df18383884872d',1,'main.cpp']]],
  ['removefuncionario_306',['removeFuncionario',['../class_base.html#af26bcd33867ddb80452f3aaeac7b1040',1,'Base']]],
  ['removerest_307',['removeRest',['../main_8cpp.html#a065a45e9a4330f34ba85dd765fe42618',1,'main.cpp']]],
  ['removerestaurante_308',['removeRestaurante',['../class_base.html#a4ae2252cefffd65f429b9243b58731b3',1,'Base']]],
  ['restaurante_309',['Restaurante',['../class_restaurante.html#ae96329273fb6568baa886d469a4b82f4',1,'Restaurante']]],
  ['restauranteinexistente_310',['RestauranteInexistente',['../class_restaurante_inexistente.html#af2ca79128c23a15ab312c183cec18196',1,'RestauranteInexistente']]],
  ['restaurantes_5freadfile_311',['restaurantes_readfile',['../class_base.html#a4becd0991c08c6c13c6e18fe983e7743',1,'Base']]]
];
