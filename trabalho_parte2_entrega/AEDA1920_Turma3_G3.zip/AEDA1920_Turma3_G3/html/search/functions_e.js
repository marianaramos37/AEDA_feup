var searchData=
[
  ['tiposculinaria_355',['tiposculinaria',['../auxiliares_8cpp.html#a06dcd1f4ba29409ae3355a96ec55f09e',1,'tiposculinaria(string tipos):&#160;auxiliares.cpp'],['../auxiliares_8h.html#a06dcd1f4ba29409ae3355a96ec55f09e',1,'tiposculinaria(string tipos):&#160;auxiliares.cpp']]]
];
