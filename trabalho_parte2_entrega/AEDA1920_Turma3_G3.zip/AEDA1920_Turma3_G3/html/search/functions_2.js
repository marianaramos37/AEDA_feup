var searchData=
[
  ['cliente_232',['Cliente',['../class_cliente.html#ab6a372f412692c12c4be4427b00a3f6e',1,'Cliente::Cliente()'],['../main_8cpp.html#a5b879c6fd207066648b08d441cae3e47',1,'cliente():&#160;main.cpp']]],
  ['clientenalistanegra_233',['ClienteNaListaNegra',['../class_cliente_na_lista_negra.html#aa1e0d8772e8147c2117722d7b8aa8839',1,'ClienteNaListaNegra']]],
  ['clientes_5freadfile_234',['clientes_readfile',['../class_base.html#af932bf79ff8b2a19ebfde91765b89531',1,'Base']]]
];
