var searchData=
[
  ['operator_3c_297',['operator&lt;',['../class_restaurante.html#a186102f7864ffed2a826985af5bf9b10',1,'Restaurante']]]
];
