var searchData=
[
  ['pratos_405',['pratos',['../class_restaurante.html#a604fca9c57419025d7dca5e6031be35c',1,'Restaurante']]],
  ['pratosnome_406',['pratosNome',['../class_encomenda.html#ada5b8ae70579980f2b625fb7c78ce8db',1,'Encomenda']]],
  ['preco_407',['preco',['../class_prato.html#a84e9828656de94a811766c909f29391b',1,'Prato::preco()'],['../class_encomenda.html#a60b87b760914a9981c7e39ae32e30329',1,'Encomenda::preco()']]]
];
