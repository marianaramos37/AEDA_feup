var searchData=
[
  ['base_10',['Base',['../class_base.html',1,'Base'],['../class_cliente.html#a69bfcaa06e14aa860b8f43d736351a59',1,'Cliente::base()'],['../class_base.html#a5ffe0568374d8b9b4c4ec32953fd6453',1,'Base::Base()'],['../class_base.html#aab2cd6a6d3797cfe53311018db92d688',1,'Base::Base(string base)']]],
  ['bases_11',['bases',['../class_empresa.html#a55bc9f3802b54e1995c37fefa10b1c9f',1,'Empresa']]]
];
