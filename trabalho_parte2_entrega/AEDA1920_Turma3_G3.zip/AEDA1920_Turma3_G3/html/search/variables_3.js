var searchData=
[
  ['data_382',['data',['../class_encomenda.html#a42a84b723169abbac9cab855f39c31c7',1,'Encomenda::data()'],['../class_funcionario.html#ab71f8641ef5217ca6229e5f5836141be',1,'Funcionario::data()']]],
  ['data_5fde_5faquisicao_383',['data_de_aquisicao',['../class_veiculo.html#ab8720495521db77f996d074572fa7313',1,'Veiculo']]],
  ['dia_384',['dia',['../class_data.html#ad76270db677fc394a4a7ded1c58de6d5',1,'Data']]],
  ['disponivel_385',['disponivel',['../class_entregador.html#aa2462d8e690c8fe35872f4c459556070',1,'Entregador']]]
];
