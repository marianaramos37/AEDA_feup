var searchData=
[
  ['restaurante_212',['Restaurante',['../class_restaurante.html',1,'']]],
  ['restauranteinexistente_213',['RestauranteInexistente',['../class_restaurante_inexistente.html',1,'']]]
];
