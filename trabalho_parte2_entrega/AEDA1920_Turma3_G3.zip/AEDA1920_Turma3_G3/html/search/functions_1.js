var searchData=
[
  ['base_231',['Base',['../class_base.html#a5ffe0568374d8b9b4c4ec32953fd6453',1,'Base::Base()'],['../class_base.html#aab2cd6a6d3797cfe53311018db92d688',1,'Base::Base(string base)']]]
];
