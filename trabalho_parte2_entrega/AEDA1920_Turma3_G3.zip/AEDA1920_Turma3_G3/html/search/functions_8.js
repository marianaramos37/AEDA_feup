var searchData=
[
  ['listaencomendas_291',['listaEncomendas',['../main_8cpp.html#a22c5c0a767c1556d64af27b34cb4cee3',1,'main.cpp']]],
  ['listanegra_5freadfile_292',['listaNegra_readfile',['../class_base.html#a714900778cfda0a00088fd36f541d99d',1,'Base']]],
  ['login_293',['login',['../main_8cpp.html#af76b7b46958dabf5e4ee9a492f0ec3fa',1,'main.cpp']]]
];
